package aulahibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {
	public static EntityManagerFactory enityManagerFactory = Persistence.createEntityManagerFactory("aulaPU");
	
	public EntityManager geEntityManager() {
		return enityManagerFactory.createEntityManager();
	}
}
