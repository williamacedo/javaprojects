package br.yahoo.William.dao;

import javax.persistence.EntityManager;

import br.yahoo.William.entidades.Contato;

public class ContatoDao {
	EntityManager em = new JPAUtil().geEntityManager();
	
	public void adiciona(Contato contato){
		em.getTransaction().begin();
		em.persist(contato);
		em.getTransaction().commit();
	}
}
