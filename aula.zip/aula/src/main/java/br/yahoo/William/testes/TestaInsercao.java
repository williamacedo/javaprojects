package br.yahoo.William.testes;

import java.util.Calendar;

import br.yahoo.William.entidades.Contato;
import br.yahoo.William.jdbc.ContatoDao;

public class TestaInsercao {
	public static void main(String[] args) {
		Contato william = new Contato();
		
		william.setNome("William de Macedo");
		william.setEmail("williamengfainor@gmail.com");
		william.setEndereco("rua tal, numero tal, bairro tal");
		william.setDataNascimento(Calendar.getInstance());
		
		ContatoDao dao = new ContatoDao();
		
		dao.adiciona(william);
		
		System.out.println("Contato salvo com sucesso");
		
	}
}
